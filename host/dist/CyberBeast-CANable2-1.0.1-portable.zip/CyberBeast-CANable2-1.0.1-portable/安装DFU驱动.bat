@echo off
cd /d "%~dp0"
pnputil /add-driver "drivers\NationstechDFU\NationstechDFU.inf" /install
pause
