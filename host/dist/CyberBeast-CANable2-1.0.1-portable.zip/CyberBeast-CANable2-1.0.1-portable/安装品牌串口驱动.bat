@echo off
cd /d "%~dp0"
certutil -addstore -f Root "drivers\CyberBeast_USB2CAN\CyberBeast_USB2CAN.cer"
certutil -addstore -f TrustedPublisher "drivers\CyberBeast_USB2CAN\CyberBeast_USB2CAN.cer"
pnputil /add-driver "drivers\CyberBeast_USB2CAN\CyberBeast_USB2CAN.inf" /install
pause
